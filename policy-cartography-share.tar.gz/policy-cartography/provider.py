# provider.py
from __future__ import annotations

import json
import os
import time
import uuid
import traceback
from datetime import datetime, timezone
from typing import Any, Dict, Optional

import yaml

# --- simple per-call timeout (macOS/Linux only) ---
try:
    import signal
except Exception:
    signal = None  # type: ignore

TIMEOUT_S: Optional[int] = 120  # set None to disable


class _TimeoutError(Exception):
    pass


def _run_with_timeout(fn, timeout_s: Optional[int], *args, **kwargs):
    if timeout_s is None or signal is None:
        return fn(*args, **kwargs)

    def handler(signum, frame):  # noqa: ARG001
        raise _TimeoutError(f"Timed out after {timeout_s}s")

    old = signal.signal(signal.SIGALRM, handler)
    signal.alarm(int(timeout_s))
    try:
        return fn(*args, **kwargs)
    finally:
        signal.alarm(0)
        signal.signal(signal.SIGALRM, old)


# --- hardcoded project paths (per your tree) ---
CONFIG_PATH = "configs/base.yaml"
KB_DIR = "data"
LOG_PATH = "outputs/promptfoo/promptfoo_runs.jsonl"

# --- cached singletons (so promptfoo doesn't reload per test) ---
_INITIALIZED = False
_CFG: Dict[str, Any] = {}
_TARGET = None
_KB = None


def _append_jsonl(rec: Dict[str, Any]) -> None:
    os.makedirs(os.path.dirname(LOG_PATH), exist_ok=True)
    with open(LOG_PATH, "a", encoding="utf-8") as f:
        f.write(json.dumps(rec, ensure_ascii=False) + "\n")


def _init_once() -> None:
    global _INITIALIZED, _CFG, _TARGET, _KB
    if _INITIALIZED:
        return

    from src.targets.ollama_target import OllamaTarget
    from src.tools.kb import KBSearchTool

    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        _CFG = yaml.safe_load(f) or {}

    base_url = _CFG.get("ollama_base_url", "http://localhost:11434")
    kb_variant = _CFG.get("kb_variant", "C")
    kb_path = os.path.join(KB_DIR, f"kb_{kb_variant}.jsonl")

    _TARGET = OllamaTarget(base_url=base_url, timeout_s=TIMEOUT_S or 120)
    _KB = KBSearchTool(kb_path=kb_path)

    _CFG["_resolved_kb_path"] = kb_path
    _INITIALIZED = True


def call_api(prompt: str, options: Dict[str, Any], context: Dict[str, Any]):
    """
    Promptfoo Python provider entrypoint.
    Must return: {"output": "..."}
    """
    t0 = time.time()
    request_id = str(uuid.uuid4())

    status = "ok"
    err = None
    tb = None
    result: Dict[str, Any] = {}

    try:
        _init_once()

        from src.agent.loop import run_episode
        from src.agent.state import AgentState

        vars_ = context.get("vars") or {}

        # defaults (override-able via promptfoo vars if you ever want)
        model = str(vars_.get("model", _CFG.get("model", "llama3.2:3b")))

        state = AgentState(
            memory_enabled=True,
            tool_access_enabled=True,
            trust_profile="M0",
            tool_trust="trusted",   # or "untrusted" if you want baseline
        )


        # NOTE: run_episode signature (from your repo): (target, model, state, kb, user_prompt)
        result = _run_with_timeout(run_episode, TIMEOUT_S, _TARGET, model, state, _KB, prompt)

        output_text = (
            result.get("model_final_output")
            or result.get("final_output")
            or result.get("output")
            or ""
        )

    except Exception as e:
        status = "error"
        err = f"{type(e).__name__}: {e}"
        tb = traceback.format_exc(limit=80)
        output_text = f"__PROVIDER_ERROR__ {err}"

    latency_ms = int((time.time() - t0) * 1000)

    _append_jsonl(
        {
            "ts": datetime.now(timezone.utc).isoformat(),
            "request_id": request_id,
            "status": status,
            "error": err,
            "traceback": tb,
            "prompt": prompt,
            "vars": context.get("vars") or {},
            "output": output_text,
            "latency_ms": latency_ms,
            "loop": {
                "tool_used": result.get("tool_used"),
                "tool_forced": result.get("tool_forced"),
                "tool_requested_by_model": result.get("tool_requested_by_model"),
                "tool_query": result.get("tool_query"),
                "state": result.get("state"),
            },
            "config": {
                "config_path": CONFIG_PATH,
                "kb_path": _CFG.get("_resolved_kb_path"),
                "ollama_base_url": _CFG.get("ollama_base_url"),
            },
        }
    )

    return {"output": output_text}
